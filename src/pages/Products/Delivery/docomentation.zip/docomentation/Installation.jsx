import DeliveryDocumentationLayout from "../../../../Layout/DeliveryDocumentationLayout";

const Installation = () => {
  return (
    <DeliveryDocumentationLayout>
      <div className="hrms-doc bg-light vh-100 bg-white w-100 ">
        Installaton
      </div>
    </DeliveryDocumentationLayout>
  );
};

export default Installation;
