import HrmsDocumentationLayout from "../../../../Layout/HrmsDocumentationLayout";

const Installation = () => {
  return (
    <HrmsDocumentationLayout>
      <div className="hrms-doc bg-light vh-100 bg-white w-100 ">
        Installaton
      </div>
    </HrmsDocumentationLayout>
  );
};

export default Installation;
